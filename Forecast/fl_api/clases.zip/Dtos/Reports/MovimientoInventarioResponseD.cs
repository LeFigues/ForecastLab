﻿namespace fl_api.Dtos.Reports
{
    public class MovimientoInventarioResponseD
    {
    }
}
