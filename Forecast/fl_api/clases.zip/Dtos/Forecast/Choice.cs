﻿namespace fl_api.Dtos.Forecast
{
    public class Choice
    {
        public ChatMessage Message { get; set; } = null!;
    }
}
