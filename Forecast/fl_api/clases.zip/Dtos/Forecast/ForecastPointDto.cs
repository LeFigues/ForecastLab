﻿namespace fl_api.Dtos.Forecast
{
    public class ForecastPointDto
    {
        public DateTime PeriodStart { get; set; }
        public double ForecastedQuantity { get; set; }
    }
}
