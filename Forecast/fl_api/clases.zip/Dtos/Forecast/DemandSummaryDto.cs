﻿namespace fl_api.Dtos
{
    public class DemandSummaryDto
    {
        public int TotalEquipmentItems { get; set; }
        public int TotalSupplyItems { get; set; }
        public int TotalReactiveItems { get; set; }
    }
}
