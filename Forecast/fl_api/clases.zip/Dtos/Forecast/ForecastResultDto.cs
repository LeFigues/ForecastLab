﻿namespace fl_api.Dtos.Forecast
{
    public class ForecastResultDto
    {
        public string Periodo { get; set; } = null!;       // "2025-06"
        public int UnidadesPronosticadas { get; set; }     // ej. 33
    }
}
