﻿namespace fl_api.Dtos.Forecast
{
    public class ForecastRequestDto
    {
        public int IdInsumo { get; set; }
        public string NombreInsumo { get; set; } = null!;
    }
}
