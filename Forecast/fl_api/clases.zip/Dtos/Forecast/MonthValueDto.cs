﻿namespace fl_api.Dtos.Forecast
{
    public class MonthValueDto
    {
        public string Periodo { get; set; } = null!;    // "2024-06"
        public int Unidades { get; set; }               // ej. 20
    }
}
