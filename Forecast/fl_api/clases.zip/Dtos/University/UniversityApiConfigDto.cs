﻿namespace fl_api.Dtos.University
{
    public class UniversityApiConfigDto
    {
        public string BaseUrl { get; set; } = null!;
        public string? ApiKey { get; set; }
    }

}
