﻿namespace fl_api.Dtos
{
    public class ChatMessage
    {
        public string Role { get; set; } = null!;
        public string Content { get; set; } = null!;
    }
}
