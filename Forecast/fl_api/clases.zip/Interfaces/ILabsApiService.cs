﻿namespace fl_api.Interfaces
{
    public interface ILabsApiService
    {
        Task<bool> CanConnectAsync();
    }
}
