﻿namespace fl_api.Interfaces
{
    public interface IStudentsApiService
    {
        Task<bool> CanConnectAsync();
    }
}
