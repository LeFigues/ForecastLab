﻿namespace fl_api.Models.Reports
{
    public class PrecioEstimado
    {
        public string Nombre { get; set; } = null!;
        public decimal Precio { get; set; }
    }
}
