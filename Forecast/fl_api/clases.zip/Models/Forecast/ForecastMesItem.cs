﻿namespace fl_api.Models.Forecast
{
    public class ForecastMesItem
    {
        public DateTime PeriodStart { get; set; }
        public int ForecastedQuantity { get; set; }
    }
}
