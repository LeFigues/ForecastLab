﻿namespace fl_api.Models
{
    public class PronosticoMensualItem
    {
        public DateTime PeriodStart { get; set; }
        public double ForecastedQuantity { get; set; }
    }
}
