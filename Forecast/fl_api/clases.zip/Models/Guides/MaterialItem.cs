﻿namespace fl_api.Models.Guides
{
    public class MaterialItem
    {
        public int Quantity { get; set; }
        public string Unit { get; set; } = null!;
        public string Description { get; set; } = null!;
    }

}
