﻿namespace fl_api.Models.Guides
{
    public class GuideAnalysisValue
    {
        public string Name { get; set; } = null!;
        public string Value { get; set; } = null!;
    }
}
